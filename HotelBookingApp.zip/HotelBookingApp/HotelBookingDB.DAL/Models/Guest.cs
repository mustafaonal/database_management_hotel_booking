﻿using System;
using System.Collections.Generic;

namespace HotelBookingDB.DAL.Models
{
    public partial class Guest
    {
        public Guest()
        {
            Booking = new HashSet<Booking>();
            HotelRating = new HashSet<HotelRating>();
        }

        public int GuestId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Sex { get; set; }
        public string Email { get; set; }
        public int AddressNumber { get; set; }
        public string AddressCity { get; set; }
        public string AddressStreet { get; set; }
        public string Phone { get; set; }
        public DateTime Birtdate { get; set; }
        public int? LoginId { get; set; }

        public Login Login { get; set; }
        public ICollection<Booking> Booking { get; set; }
        public ICollection<HotelRating> HotelRating { get; set; }
    }
}
