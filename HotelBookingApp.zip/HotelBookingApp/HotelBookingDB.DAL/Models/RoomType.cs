﻿using System;
using System.Collections.Generic;

namespace HotelBookingDB.DAL.Models
{
    public partial class RoomType
    {
        public int TypeId { get; set; }
        public int MaxGuest { get; set; }
        public int RoomPrice { get; set; }
        public int TotalRooms { get; set; }
        public int RoomNo { get; set; }

        public Room RoomNoNavigation { get; set; }
    }
}
