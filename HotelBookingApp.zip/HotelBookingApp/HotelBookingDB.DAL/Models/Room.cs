﻿using System;
using System.Collections.Generic;

namespace HotelBookingDB.DAL.Models
{
    public partial class Room
    {
        public Room()
        {
            RoomType = new HashSet<RoomType>();
        }

        public int RoomNo { get; set; }
        public string RoomStatus { get; set; }
        public int HotelId { get; set; }

        public Hotel Hotel { get; set; }
        public ICollection<RoomType> RoomType { get; set; }
    }
}
