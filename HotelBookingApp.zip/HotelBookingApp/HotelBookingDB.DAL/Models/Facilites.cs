﻿using System;
using System.Collections.Generic;

namespace HotelBookingDB.DAL.Models
{
    public partial class Facilites
    {
        public int FacilityId { get; set; }
        public string FacilityName { get; set; }
        public string FacilityDescript { get; set; }
        public string FacilityType { get; set; }
        public int? FacilityPrice { get; set; }
        public int HotelId { get; set; }

        public Hotel Hotel { get; set; }
    }
}
