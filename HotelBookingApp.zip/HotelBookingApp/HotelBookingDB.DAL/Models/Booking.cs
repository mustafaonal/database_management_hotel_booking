﻿using System;
using System.Collections.Generic;

namespace HotelBookingDB.DAL.Models
{
    public partial class Booking
    {
        public Booking()
        {
            Billing = new HashSet<Billing>();
        }

        public int BookingId { get; set; }
        public int GuestId { get; set; }
        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }

        public Guest Guest { get; set; }
        public ICollection<Billing> Billing { get; set; }
    }
}
