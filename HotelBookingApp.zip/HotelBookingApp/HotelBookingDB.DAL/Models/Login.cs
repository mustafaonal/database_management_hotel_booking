﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HotelBookingDB.DAL.Models
{
    public partial class Login
    {
        public Login()
        {
            Guest = new HashSet<Guest>();
        }
        [Key]
        public int LoginId { get; set; }
        public string Password { get; set; }
        public string LoginUsername { get; set; }
        public string Email { get; set; }

        public ICollection<Guest> Guest { get; set; }
    }
}
