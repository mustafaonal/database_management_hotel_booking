﻿using System;
using System.Collections.Generic;

namespace HotelBookingDB.DAL.Models
{
    public partial class HotelRating
    {
        public int HotelRatingId { get; set; }
        public int HotelId { get; set; }
        public int GuestId { get; set; }
        public int Rate { get; set; }

        public Guest Guest { get; set; }
        public Hotel Hotel { get; set; }
    }
}
