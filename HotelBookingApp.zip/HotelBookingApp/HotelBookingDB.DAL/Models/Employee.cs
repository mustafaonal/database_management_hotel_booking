﻿using System;
using System.Collections.Generic;

namespace HotelBookingDB.DAL.Models
{
    public partial class Employee
    {
        public int EmpId { get; set; }
        public string EmpFirstName { get; set; }
        public string EmpLastName { get; set; }
        public string EmpSex { get; set; }
        public DateTime? EmpBirthdate { get; set; }
        public int EmpSalary { get; set; }
        public int SuperId { get; set; }
        public int HotelId { get; set; }

        public Hotel Hotel { get; set; }
    }
}
