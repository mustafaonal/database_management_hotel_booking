﻿using System;
using System.Collections.Generic;

namespace HotelBookingDB.DAL.Models
{
    public partial class Billing
    {
        public int BillId { get; set; }
        public int BookingId { get; set; }
        public int TotalPrice { get; set; }
        public DateTime BillDate { get; set; }

        public Booking Booking { get; set; }
    }
}
