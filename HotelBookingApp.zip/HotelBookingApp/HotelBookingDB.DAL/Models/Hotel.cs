﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace HotelBookingDB.DAL.Models
{
    public partial class Hotel
    {
        public Hotel()
        {
            Employee = new HashSet<Employee>();
            Facilites = new HashSet<Facilites>();
            HotelRating = new HashSet<HotelRating>();
            Room = new HashSet<Room>();
        }
        [Key]
        public int HotelId { get; set; }
        [DisplayName("Name")]
        public string HotelName { get; set; }
        [DisplayName("Address")]
        public string HotelAddr { get; set; }
        [DisplayName("Capacity")]
        public int Capacity { get; set; }
        [DisplayName("City")]
        public string HotelCity { get; set; }

        public ICollection<Employee> Employee { get; set; }
        public ICollection<Facilites> Facilites { get; set; }
        public ICollection<HotelRating> HotelRating { get; set; }
        public ICollection<Room> Room { get; set; }
    }
}
