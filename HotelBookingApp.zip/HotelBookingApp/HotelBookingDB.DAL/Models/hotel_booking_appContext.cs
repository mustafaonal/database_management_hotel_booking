﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace HotelBookingDB.DAL.Models
{
    public partial class hotel_booking_appContext : DbContext
    {
        public hotel_booking_appContext()
        {
        }

        public hotel_booking_appContext(DbContextOptions<hotel_booking_appContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Billing> Billing { get; set; }
        public virtual DbSet<Booking> Booking { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<Facilites> Facilites { get; set; }
        public virtual DbSet<Guest> Guest { get; set; }
        public virtual DbSet<Hotel> Hotel { get; set; }
        public virtual DbSet<HotelRating> HotelRating { get; set; }
        public virtual DbSet<Login> Login { get; set; }
        public virtual DbSet<Room> Room { get; set; }
        public virtual DbSet<RoomType> RoomType { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseNpgsql("Host=localhost;Database=hotel_booking_app;Username=postgres;Password=admin;Port=5432");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Billing>(entity =>
            {
                entity.HasKey(e => e.BillId);

                entity.ToTable("billing", "hotel_booking_app");

                entity.Property(e => e.BillId)
                    .HasColumnName("bill_id")
                    .HasDefaultValueSql("nextval('hotel_booking_app.billing_bill_id_seq'::regclass)");

                entity.Property(e => e.BillDate)
                    .HasColumnName("bill_date")
                    .HasColumnType("date");

                entity.Property(e => e.BookingId).HasColumnName("booking_id");

                entity.Property(e => e.TotalPrice).HasColumnName("total_price");

                entity.HasOne(d => d.Booking)
                    .WithMany(p => p.Billing)
                    .HasForeignKey(d => d.BookingId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("billing_booking_id_fkey");
            });

            modelBuilder.Entity<Booking>(entity =>
            {
                entity.ToTable("booking", "hotel_booking_app");

                entity.Property(e => e.BookingId)
                    .HasColumnName("booking_id")
                    .HasDefaultValueSql("nextval('hotel_booking_app.booking_booking_id_seq'::regclass)");

                entity.Property(e => e.CheckInDate)
                    .HasColumnName("check_in_date")
                    .HasColumnType("date");

                entity.Property(e => e.CheckOutDate)
                    .HasColumnName("check_out_date")
                    .HasColumnType("date");

                entity.Property(e => e.GuestId).HasColumnName("guest_id");

                entity.HasOne(d => d.Guest)
                    .WithMany(p => p.Booking)
                    .HasForeignKey(d => d.GuestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("booking_guest_id_fkey");
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.EmpId);

                entity.ToTable("employee", "hotel_booking_app");

                entity.Property(e => e.EmpId)
                    .HasColumnName("emp_id")
                    .HasDefaultValueSql("nextval('hotel_booking_app.employee_emp_id_seq'::regclass)");

                entity.Property(e => e.EmpBirthdate)
                    .HasColumnName("emp_birthdate")
                    .HasColumnType("date");

                entity.Property(e => e.EmpFirstName)
                    .IsRequired()
                    .HasColumnName("emp_first_name");

                entity.Property(e => e.EmpLastName)
                    .IsRequired()
                    .HasColumnName("emp_last_name");

                entity.Property(e => e.EmpSalary).HasColumnName("emp_salary");

                entity.Property(e => e.EmpSex)
                    .HasColumnName("emp_sex")
                    .HasColumnType("character varying(50)");

                entity.Property(e => e.HotelId).HasColumnName("hotel_id");

                entity.Property(e => e.SuperId)
                    .HasColumnName("super_id")
                    .HasDefaultValueSql("nextval('hotel_booking_app.employee_super_id_seq'::regclass)");

                entity.HasOne(d => d.Hotel)
                    .WithMany(p => p.Employee)
                    .HasForeignKey(d => d.HotelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("employee_hotel_id_fkey");
            });

            modelBuilder.Entity<Facilites>(entity =>
            {
                entity.HasKey(e => e.FacilityId);

                entity.ToTable("facilites", "hotel_booking_app");

                entity.Property(e => e.FacilityId)
                    .HasColumnName("facility_id")
                    .HasDefaultValueSql("nextval('hotel_booking_app.facilites_facility_id_seq'::regclass)");

                entity.Property(e => e.FacilityDescript).HasColumnName("facility_descript");

                entity.Property(e => e.FacilityName)
                    .IsRequired()
                    .HasColumnName("facility_name");

                entity.Property(e => e.FacilityPrice).HasColumnName("facility_price");

                entity.Property(e => e.FacilityType).HasColumnName("facility_type");

                entity.Property(e => e.HotelId).HasColumnName("hotel_id");

                entity.HasOne(d => d.Hotel)
                    .WithMany(p => p.Facilites)
                    .HasForeignKey(d => d.HotelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("facilites_hotel_id_fkey");
            });

            modelBuilder.Entity<Guest>(entity =>
            {
                entity.ToTable("guest", "hotel_booking_app");

                entity.HasIndex(e => e.Email)
                    .HasName("guest_email_key")
                    .IsUnique();

                entity.Property(e => e.GuestId)
                    .HasColumnName("guest_id")
                    .HasDefaultValueSql("nextval('hotel_booking_app.guest_guest_id_seq'::regclass)");

                entity.Property(e => e.AddressCity)
                    .IsRequired()
                    .HasColumnName("address_city");

                entity.Property(e => e.AddressNumber).HasColumnName("address_number");

                entity.Property(e => e.AddressStreet)
                    .IsRequired()
                    .HasColumnName("address_street");

                entity.Property(e => e.Birtdate)
                    .HasColumnName("birtdate")
                    .HasColumnType("date");

                entity.Property(e => e.Email).HasColumnName("email");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnName("first_name");

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasColumnName("last_name");

                entity.Property(e => e.LoginId).HasColumnName("login_id");

                entity.Property(e => e.Phone)
                    .IsRequired()
                    .HasColumnName("phone")
                    .HasColumnType("character varying(20)");

                entity.Property(e => e.Sex)
                    .HasColumnName("sex")
                    .HasColumnType("character varying(50)");

                entity.HasOne(d => d.Login)
                    .WithMany(p => p.Guest)
                    .HasForeignKey(d => d.LoginId)
                    .HasConstraintName("guest_login_id_fkey");
            });

            modelBuilder.Entity<Hotel>(entity =>
            {
                entity.ToTable("hotel", "hotel_booking_app");

                entity.HasIndex(e => new { e.HotelName, e.HotelAddr })
                    .HasName("hotel_hotel_name_hotel_addr_key")
                    .IsUnique();

                entity.Property(e => e.HotelId)
                    .HasColumnName("hotel_id")
                    .HasDefaultValueSql("nextval('hotel_booking_app.hotel_hotel_id_seq'::regclass)");

                entity.Property(e => e.Capacity).HasColumnName("capacity");

                entity.Property(e => e.HotelAddr)
                    .IsRequired()
                    .HasColumnName("hotel_addr");

                entity.Property(e => e.HotelCity).HasColumnName("hotel_city");

                entity.Property(e => e.HotelName)
                    .IsRequired()
                    .HasColumnName("hotel_name");
            });

            modelBuilder.Entity<HotelRating>(entity =>
            {
                entity.ToTable("hotel_rating", "hotel_booking_app");

                entity.Property(e => e.HotelRatingId)
                    .HasColumnName("hotel_rating_id")
                    .HasDefaultValueSql("nextval('hotel_booking_app.hotel_rating_hotel_rating_id_seq'::regclass)");

                entity.Property(e => e.GuestId).HasColumnName("guest_id");

                entity.Property(e => e.HotelId).HasColumnName("hotel_id");

                entity.Property(e => e.Rate).HasColumnName("rate");

                entity.HasOne(d => d.Guest)
                    .WithMany(p => p.HotelRating)
                    .HasForeignKey(d => d.GuestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("hotel_rating_guest_id_fkey");

                entity.HasOne(d => d.Hotel)
                    .WithMany(p => p.HotelRating)
                    .HasForeignKey(d => d.HotelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("hotel_rating_hotel_id_fkey");
            });

            modelBuilder.Entity<Login>(entity =>
            {
                entity.ToTable("login", "hotel_booking_app");

                entity.HasIndex(e => e.Email)
                    .HasName("login_email_key")
                    .IsUnique();

                entity.Property(e => e.LoginId)
                    .HasColumnName("login_id")
                    .HasDefaultValueSql("nextval('hotel_booking_app.login_login_id_seq'::regclass)");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnName("email");

                entity.Property(e => e.LoginUsername)
                    .IsRequired()
                    .HasColumnName("login_username");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password");
            });

            modelBuilder.Entity<Room>(entity =>
            {
                entity.HasKey(e => e.RoomNo);

                entity.ToTable("room", "hotel_booking_app");

                entity.Property(e => e.RoomNo)
                    .HasColumnName("room_no")
                    .ValueGeneratedNever();

                entity.Property(e => e.HotelId).HasColumnName("hotel_id");

                entity.Property(e => e.RoomStatus)
                    .IsRequired()
                    .HasColumnName("room_status");

                entity.HasOne(d => d.Hotel)
                    .WithMany(p => p.Room)
                    .HasForeignKey(d => d.HotelId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("room_hotel_id_fkey");
            });

            modelBuilder.Entity<RoomType>(entity =>
            {
                entity.HasKey(e => e.TypeId);

                entity.ToTable("room_type", "hotel_booking_app");

                entity.Property(e => e.TypeId)
                    .HasColumnName("type_id")
                    .HasDefaultValueSql("nextval('hotel_booking_app.room_type_type_id_seq'::regclass)");

                entity.Property(e => e.MaxGuest).HasColumnName("max_guest");

                entity.Property(e => e.RoomNo).HasColumnName("room_no");

                entity.Property(e => e.RoomPrice).HasColumnName("room_price");

                entity.Property(e => e.TotalRooms).HasColumnName("total_rooms");

                entity.HasOne(d => d.RoomNoNavigation)
                    .WithMany(p => p.RoomType)
                    .HasForeignKey(d => d.RoomNo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("room_type_room_no_fkey");
            });

            modelBuilder.HasSequence<int>("billing_bill_id_seq");

            modelBuilder.HasSequence<int>("booking_booking_id_seq");

            modelBuilder.HasSequence<int>("employee_emp_id_seq");

            modelBuilder.HasSequence<int>("employee_super_id_seq");

            modelBuilder.HasSequence<int>("facilites_facility_id_seq");

            modelBuilder.HasSequence<int>("guest_guest_id_seq");

            modelBuilder.HasSequence<int>("hotel_hotel_id_seq");

            modelBuilder.HasSequence<int>("hotel_rating_hotel_rating_id_seq");

            modelBuilder.HasSequence<int>("login_login_id_seq");

            modelBuilder.HasSequence<int>("room_type_type_id_seq");
        }
    }
}
